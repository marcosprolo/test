'use strict';

console.log('Loading function');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = (event, context, callback) => {
    let scanningParameters = {
        TableName: "Token",
    };
    docClient.scan(scanningParameters, function(err, data){
        if(err){
            callback(err, null);
        }else{
            var datetime = Math.floor(Date.now() / 1000);
            var num1 = 0;
            //callback(null, data);
           while(num1 < data.ScannedCount){
                if(data.Items[num1].expiration < datetime){
                    console.log(data.Items[num1].expiration);
                    var params = {
                        TableName:"Token",
                        Key: {"token": data.Items[num1].token,
                        },
                    };
                    docClient.delete(params, function(err, data) {
                        if (err) {
                            console.error("Unable to delete item. Error JSON:", JSON.stringify(err, null, 2));
                        } else {
                            console.log("DeleteItem succeeded:", JSON.stringify(data, null, 2));
                        }
                    });
                }
                num1++;
            }
        }
    });
};

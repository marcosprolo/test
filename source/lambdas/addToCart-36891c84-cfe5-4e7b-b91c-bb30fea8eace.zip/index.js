'use strict';

console.log('Loading function');

const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = (event, context, callback) => {
    if(event.flag === true){
        var params2 = {
            TableName: "Token",
            Key: {"token": event.cookie},
        }
        
    docClient.get(params2, function(err, data){
        if(data.Item === undefined){
            callback("Bad parameter, token malformed.",null);
        }else{
        if(err){
            callback(err, null);
        }else{
            var datetime = Math.floor(Date.now() / 1000);
            if(data.Item.expiration > datetime){
                var params = {
                    Item: {
                        id: event.id,
                        prod_id: parseInt(event.prod_id),
                        cookie: data.Item.username
                    },
                    TableName: 'Cart'
                };
                docClient.put(params, function(err, data){
                    if(err){
                        callback(err, null);
                    }else{
                        callback(null, data);
                    }
                });
            }else{
                callback("Your token has expired, please login again.",null);
            }
        }
        }
    });
    }else if(event.flag === false){
        var params = {
            Item: {
                id: event.id,
                prod_id: parseInt(event.prod_id),
                cookie: event.cookie
            },
            TableName: 'Cart'
        };
        docClient.put(params, function(err, data){
            if(err){
                callback(err, null);
            }else{
                callback(null, data);
            }
        });
    }else{
        callback('Bad parameter, flag is incorrect.',null);
    }
}

'use strict';

console.log('Loading function');

const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = (event, context, callback) => {
        var params1 = {
            TableName: "User",
            Key: {"username": event.username},
            //Key: {"token": "bHVpczQ1NjE0OTM0MDMxMjk"},
        };
        docClient.get(params1, function(err, data){
            if(data.Item === undefined){
                var params = {
                    Item: {
                        username: event.username,
                        password: event.password            
                    },
                    TableName: 'User'
                };
                
                docClient.put(params, function(err, data){
                    if(err){
                        callback(err, null);
                    }else{
                        console.log(data);
                        callback(null, data);
                    }
                });
            }else{
                callback("This user already exist.",null);
            }
    });
}


'use strict';

console.log('Loading function');

const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = (event, context, callback) => {
    if(event.flag === true){
    var params2 = {
        TableName: "Token",
        Key: {"token": event.cookie},
    }
        
    docClient.get(params2, function(err, data){
        if(data.Item === undefined){
            callback("Bad parameter, token malformed.",null);
        }else{
        if(err){
            callback(err, null);
        }else{
            var datetime = Math.floor(Date.now() / 1000);
            if(data.Item.expiration > datetime){
                let scanningParameters = {
                    TableName: "Cart",
                    FilterExpression:"cookie = :cookie",
                    ExpressionAttributeValues:{
                        ":cookie": data.Item.username
                    },
                    Limit: 10000
                };
                docClient.scan(scanningParameters, function(err, data){
                    if(err){
                        callback(err, null);
                    }else{
                        callback(null, data);
                    }
                });
            }else{
                callback("Your token has expired, please login again.",null);
            }
        }
        }
    });
    }else if(event.flag === false){
        let scanningParameters = {
            TableName: "Cart",
            FilterExpression:"cookie = :cookie",
            ExpressionAttributeValues:{
                ":cookie": event.cookie
            },
            Limit: 10000
        };
        docClient.scan(scanningParameters, function(err, data){
            if(err){
                callback(err, null);
            }else{
                callback(null, data);
            }
        });
    }else{
        callback('Bad parameter, flag is incorrect.',null);
    }
}
